public class CartaLacaio {
	
	private int ID;
	private String nome;
	private int ataque;
	private int vidaAtual;
	private int vidaMaxima;
	private int custoMana;
	
	// Metodo construtor aqui
	
	// Demais metodos aqui
	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

}
